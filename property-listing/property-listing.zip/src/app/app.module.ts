import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core'; 
import {Http, HttpModule  } from '@angular/http';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap'

import { AppComponent } from './app.component';
import { AsyncAwareButton } from './async-aware-button';
import {SearchService} from './search.service';


@NgModule({
  declarations: [
    AppComponent,
    AsyncAwareButton
  ],
  imports: [
    BrowserModule,   HttpModule,  
    NgbModule.forRoot(),

  ],
  providers: [SearchService],
  bootstrap: [AppComponent]
})
export class AppModule { }
